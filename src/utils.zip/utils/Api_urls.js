export const urls = {
  // API: "http://192.168.100.35/couaff_new/api/",
  // PHP_API: "http://192.168.100.35/couaff_new/",
  // Image_Uri: "http://192.168.100.35/couaff_new/api/",

  // API: "https://cauaff.fictiondevelopers.com/api/",
  // PHP_API: "https://cauaff.fictiondevelopers.com",
  // Image_Uri: "https://cauaff.fictiondevelopers.com/api/",

  API: "https://admin.couaff.com/api/",
  PHP_API: "https://admin.couaff.com/",
  Image_Uri: "https://admin.couaff.com/api/",

  //... more colors here
  MARGIN: false,
  error_title: "No Internet",
  error: "Error connecting to the server, please try again later",
  D_LIMIT: 120

  // mersruveysapp@gmail.com
  // P145DeDevelopers
};